//
//  UniversityListViewController.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

class UniversityListViewController: UIViewController, UniversityListViewProtocol {
    
    //MARK: Properties
    var presenter: UniversityListPresenterProtocol?
    private var universities: [UniversityListModel]?
    
    //MARK: IBOutlets
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleRefreshRequest), name: .didRequestRefresh, object: nil)
        setupUI()
        presenter?.viewDidLoad()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: .didRequestRefresh, object: nil)
    }
    
    func displayUniversities(_ universities: [UniversityListModel]) {
        self.universities = universities
        reloadTableView()
    }
    
    func displayError(_ error: String) {
        activityIndicatorView.stopAnimating()
        showAlert(withTitle: "", withMessage: "\(error)")
    }
}

//MARK: - private extension
private extension UniversityListViewController {
    func setupUI() {
        startLoader()
        listTableView.dataSource = self
        listTableView.delegate = self
        listTableView.registerNib(forCellClass: UniversityListTableViewCell.self)
    }
    
    @objc func handleRefreshRequest() {
        startLoader()
        presenter?.viewDidLoad()
    }
    
    func reloadTableView() {
        DispatchQueue.main.async { [weak self] in
            self?.listTableView.reloadData()
            self?.stopLoader()
        }
    }
    
    func startLoader() {
        activityIndicatorView.startAnimating()
    }
    
    func stopLoader() {
        activityIndicatorView.stopAnimating()
    }
}

//MARK: - UITableViewDelegate, UITableViewDataSource
extension UniversityListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        universities?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.universityListCell, for: indexPath) as? UniversityListTableViewCell else { return UITableViewCell() }
        
        if let university = universities?[indexPath.row] {
            cell.configureCell(data: university)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let selectedUniversity = universities?[indexPath.row] {
            presenter?.didSelectUniversity(selectedUniversity)
        }
    }
}
