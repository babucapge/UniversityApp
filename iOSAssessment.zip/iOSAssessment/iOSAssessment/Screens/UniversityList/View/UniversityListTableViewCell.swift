//
//  UniversityListTableViewCell.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

class UniversityListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblUniversityName: UILabel!
    @IBOutlet weak var lblUniversityState: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(data: UniversityListModel) {
        lblUniversityName.text = data.name
        lblUniversityState.text = data.stateProvince
    }
    
}
