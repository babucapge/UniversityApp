//
//  UniversityListRouter.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

class UniversityListRouter: UniversityListRouterProtocol {
    weak var viewController: UIViewController?

    func navigateToDetails(with university: UniversityListModel) {
        let detailsVC = UniversityDetailsRouter.createModule(with: university)
        viewController?.present(detailsVC, animated: true, completion: nil)
    }
    
    static func createModule() -> UIViewController {
        let view: UniversityListViewController = UIStoryboard.instantiateViewController(ofType: UniversityListViewController.self)

        let presenter = UniversityListPresenter()
        let interactor = UniversityListInteractor()
        let router = UniversityListRouter()

        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        interactor.presenter = presenter
        router.viewController = view
        view.presenter = presenter

        return view
    }
}
