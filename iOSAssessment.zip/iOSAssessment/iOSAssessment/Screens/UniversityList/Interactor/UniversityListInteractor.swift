//
//  UniversityListInteractor.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation

class UniversityListInteractor: UniversityListInteractorInputProtocol {
    var presenter: UniversityListInteractorOutputProtocol?
    private let service = NetworkManager.shared
    private let database: DatabaseManager<UniversityListModel> = DatabaseManager<UniversityListModel>.shared
    
    func fetchUniversities() {
        let universitiesAPI = URL(string: Constant.API.baseURL+Constant.API.listUniversities)!
        NetworkManager.shared.fetchData(requestUrl: universitiesAPI, resultType: [UniversityListModel].self) { [weak self] result in
            DispatchQueue.main.async {
                
                switch result {
                case .success(let universities):
                    guard !universities.isEmpty else {
                        if let universities = self?.database.fetchItems(), !universities.isEmpty {
                            self?.presenter?.didFetchUniversities(universities)
                        }
                        return
                    }
                    self?.database.saveItems(universities)
                    self?.presenter?.didFetchUniversities(universities)
                    
                case .failure(let error):
                    guard let universities = self?.database.fetchItems(), !universities.isEmpty else {
                        self?.presenter?.didFailToFetchUniversities(error.errorDescription)
                        return
                    }
                    
                    self?.presenter?.didFetchUniversities(universities)
                }
            }
        }
    }
}
