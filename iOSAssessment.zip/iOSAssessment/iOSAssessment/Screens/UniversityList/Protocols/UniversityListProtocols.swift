//
//  UniversityListProtocols.swift
//  iOSAssessment
//
//  Created by Babu on 30/07/24.
//

import Foundation

//MARK: Interactor
protocol UniversityListInteractorInputProtocol {
    func fetchUniversities()
}

protocol UniversityListInteractorOutputProtocol: AnyObject {
    func didFetchUniversities(_ universities: [UniversityListModel])
    func didFailToFetchUniversities(_ error: String)
}

//MARK: Presenter
protocol UniversityListPresenterProtocol {
    func viewDidLoad()
    func didSelectUniversity(_ university: UniversityListModel)
}

protocol UniversityListViewProtocol: AnyObject {
    func displayUniversities(_ universities: [UniversityListModel])
    func displayError(_ error: String)
}

//MARK: Router
protocol UniversityListRouterProtocol {
    func navigateToDetails(with university: UniversityListModel)
}
