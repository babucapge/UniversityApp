//
//  UniversityListPresenter.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation

class UniversityListPresenter: UniversityListPresenterProtocol, UniversityListInteractorOutputProtocol {
    weak var view: UniversityListViewProtocol?
    var interactor: UniversityListInteractorInputProtocol?
    var router: UniversityListRouterProtocol?
    
    func viewDidLoad() {
        interactor?.fetchUniversities()
    }

    func didFetchUniversities(_ universities: [UniversityListModel]) {
        view?.displayUniversities(universities)
    }

    func didFailToFetchUniversities(_ error: String) {
        view?.displayError(error)
    }
    
    func didSelectUniversity(_ university: UniversityListModel) {
        router?.navigateToDetails(with: university)
    }
}
