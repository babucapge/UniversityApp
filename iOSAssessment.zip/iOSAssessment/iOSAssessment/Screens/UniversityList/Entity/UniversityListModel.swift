//
//  UniversityListModel.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation
import RealmSwift
import Realm

// MARK: - University
class UniversityListModel: Object, Decodable {
    @Persisted var alphaTwoCode: String = ""
    @Persisted var webPages = List<String>()
    @Persisted var country: String = ""
    @Persisted var domains = List<String>()
    @Persisted var name: String = ""
    @Persisted var stateProvince: String?

    override static func primaryKey() -> String? {
        return "name"
    }

    private enum CodingKeys: String, CodingKey {
        case alphaTwoCode = "alpha_two_code"
        case webPages = "web_pages"
        case country
        case domains
        case name
        case stateProvince = "state-province"
    }

    convenience required init(from decoder: Decoder) throws {
        self.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.alphaTwoCode = try container.decode(String.self, forKey: .alphaTwoCode)
        self.country = try container.decode(String.self, forKey: .country)
        self.name = try container.decode(String.self, forKey: .name)
        self.stateProvince = try container.decodeIfPresent(String.self, forKey: .stateProvince)
        
        let webPagesArray = try container.decode([String].self, forKey: .webPages)
        self.webPages.append(objectsIn: webPagesArray)
        
        let domainsArray = try container.decode([String].self, forKey: .domains)
        self.domains.append(objectsIn: domainsArray)
    }
}
