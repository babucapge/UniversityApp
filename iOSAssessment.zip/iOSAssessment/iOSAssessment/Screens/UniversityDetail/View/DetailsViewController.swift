//
//  UniversityDetailsViewController.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

class UniversityDetailsViewController: UIViewController, UniversityDetailsViewProtocol {
    var presenter: UniversityDetailsPresenterProtocol?
    private var university: UniversityListModel?
    
    @IBOutlet weak var lblUniversityName: UILabel!
    @IBOutlet weak var lblUniversityState: UILabel!
    @IBOutlet weak var lblCountryName: UILabel!
    @IBOutlet weak var lblWebPage: UILabel!
    @IBOutlet weak var lblCountryCode: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter?.viewDidLoad()
    }
    
    func displayUniversity(_ university: UniversityListModel) {
        self.university = university
        setupUI()
    }
    
    //MARK: IBAction
    @IBAction func btnPullToRefresh(_ sender: Any) {
        presenter?.didTapRefresh()
    }
}

//MARK: - private extension
private extension UniversityDetailsViewController {
    func setupUI() {
        lblUniversityName.text = university?.name
        lblUniversityState.text = university?.stateProvince
        lblCountryName.text = university?.country
        lblWebPage.text = university?.webPages.first
        lblCountryCode.text = university?.alphaTwoCode
    }
}
