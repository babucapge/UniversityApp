//
//  UniversityDetailsPresenter.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation

class UniversityDetailsPresenter: UniversityDetailsPresenterProtocol {
    weak var view: UniversityDetailsViewProtocol?
    var university: UniversityListModel?
    var router: UniversityDetailsRouterProtocol?
    
    func viewDidLoad() {
        if let university = university {
            view?.displayUniversity(university)
        }
    }
    
    func didTapRefresh() {
        router?.refreshListing()
    }
}
