//
//  UniversityDetailsInteractor.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation
