//
//  UniversityDetailProtocol.swift
//  iOSAssessment
//
//  Created by Babu on 30/07/24.
//

import Foundation

//MARK: Presenter
protocol UniversityDetailsPresenterProtocol {
    func viewDidLoad()
    func didTapRefresh()
}

protocol UniversityDetailsViewProtocol: AnyObject {
    func displayUniversity(_ university: UniversityListModel)
}


//MARK: Router
protocol UniversityDetailsRouterProtocol {
    func refreshListing()
}
