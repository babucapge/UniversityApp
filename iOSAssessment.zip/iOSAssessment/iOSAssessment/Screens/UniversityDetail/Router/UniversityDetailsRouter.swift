//
//  UniversityDetailsRouter.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

class UniversityDetailsRouter: UniversityDetailsRouterProtocol {
    weak var viewController: UIViewController?
    
    func refreshListing() {
        viewController?.dismiss(animated: true, completion: {
            NotificationCenter.default.post(name: .didRequestRefresh, object: nil)
        })
    }
    
    static func createModule(with university: UniversityListModel) -> UIViewController {
        let view: UniversityDetailsViewController = UIStoryboard.instantiateViewController(ofType: UniversityDetailsViewController.self)
        let presenter = UniversityDetailsPresenter()
        let router = UniversityDetailsRouter()
        
        view.presenter = presenter
        presenter.view = view
        presenter.university = university
        presenter.router = router
        router.viewController = view
        
        return view
    }
}
