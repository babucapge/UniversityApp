//
//  Constant.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

//MARK: - Constant
enum Constant {
    
    //MARK: APIs
    enum API {
        static let baseURL = "http://universities.hipolabs.com/"
        static let listUniversities = "search?country=United%20Arab%20Emirates"
    }
    
    //MARK: CellIdentifiers
    enum CellIdentifier {
        static let universityListCell = "UniversityListTableViewCell"
    }
    
    //MARK: Buttons
    static let Ok = "OK"
}
