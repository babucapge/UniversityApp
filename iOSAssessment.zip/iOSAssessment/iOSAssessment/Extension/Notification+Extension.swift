//
//  Notification+Extension.swift
//  iOSAssessment
//
//  Created by Babu on 30/07/24.
//

import Foundation

extension Notification.Name {
    static let didRequestRefresh = Notification.Name("didRequestRefresh")
}
