//
//  UIViewController+Extension.swift
//  iOSAssessment
//
//  Created by Babu on 30/07/24.
//

import UIKit

// MARK: - UIViewController extension
extension  UIViewController {
    
    // MARK: Alert

    /// It will show the alert based on title and message.
    ///
    /// - Parameters:
    ///   - title: `String` value to show error title to user.
    ///   - message: `String` value to show error message to user.
    ///
    func showAlert(withTitle title: String, withMessage message:String) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: Constant.Ok, style: .default, handler: { action in
            alert.dismiss(animated: true)
        })
        alert.addAction(ok)
        DispatchQueue.main.async(execute: { [weak self] in
            guard let self = self else { return }
            self.present(alert, animated: true)
        })
    }
    
}
