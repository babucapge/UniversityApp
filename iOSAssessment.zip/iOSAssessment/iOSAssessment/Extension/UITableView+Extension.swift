//
//  UITableView+Extension.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import UIKit

// MARK: - UITableView extension
extension UITableView {
    
    /// It's used to register cell nib for UITableViewCell
    ///
    /// - Parameters:
    ///   - cellClass: `Generic Type` it accept the tableview cell.
    ///
    func registerNib<T: UITableViewCell>(forCellClass cellClass: T.Type)  {
        
        let nib = UINib(nibName: String(describing: cellClass), bundle: nil)
        register(nib, forCellReuseIdentifier: String(describing: cellClass))
    }
    
}
