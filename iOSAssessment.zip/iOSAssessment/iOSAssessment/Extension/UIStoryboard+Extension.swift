//
//  UIStoryboard+Extension.swift
//  iOSAssessment
//
//  Created by Babu on 30/07/24.
//

import UIKit

//MARK: - UIStoryboard extension
extension UIStoryboard {
    
    /// It's used to instantiate ViewController
    ///
    /// - Parameters:
    ///   - ofType: `Generic Type` it accept the UIViewController.
    ///
    static func instantiateViewController<T: UIViewController>(ofType type: T.Type) -> T {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        guard let viewController = storyboard.instantiateViewController(withIdentifier: String(describing: type)) as? T else {
            fatalError("ViewController with identifier \(String(describing: type)) not found in Main storyboard.")
        }
        return viewController
    }
}
