//
//  DatabaseManager.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation
import RealmSwift

final class DatabaseManager<T: Object> {
    static var shared: DatabaseManager<T> {
        return DatabaseManager<T>()
    }
    
    func saveItems(_ items: [T]) {
        let realm = try! Realm()
        try! realm.write {
            realm.add(items, update: .modified)
        }
    }
    
    func fetchItems() -> [T]? {
        let realm = try! Realm()
        return Array(realm.objects(T.self))
    }
}
