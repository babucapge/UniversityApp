//
//  NetworkManager.swift
//  iOSAssessment
//
//  Created by Babu on 29/07/24.
//

import Foundation

enum APIError: Error {
    case noInternet
    case invalidURL
    case invalidData
    case invalidResponse
    case decodingError(_ error: String?)
    case unknownError(_ error: String?)
    
    var errorDescription: String {
        switch self {
        case .invalidResponse:
           return "Invalid Response"
        case .invalidURL:
           return "Invalid URL"
        case .invalidData:
           return "Invalid Data"
        case .noInternet:
           return "No Internet"
        default:
            return "Unknown Error"
        }
    }
}

final class NetworkManager {
    static let shared = NetworkManager()
    
    func fetchData<T: Decodable>(requestUrl: URL, resultType: T.Type, completionHandler: @escaping (Result<T, APIError>) -> Void) {
        
        if !Reachability.isConnectedToNetwork() {
            completionHandler(.failure(.noInternet))
            return
        }
        
        URLSession.shared.dataTask(with: requestUrl) { (responseData, httpUrlResponse, error) in
            if let error = error {
                completionHandler(.failure(.unknownError(error.localizedDescription)))
                return
            }
            
            guard let httpUrlResponse = httpUrlResponse as? HTTPURLResponse, 200..<300 ~= httpUrlResponse.statusCode else {
                completionHandler(.failure(.invalidResponse))
                return
            }
            
            guard let data = responseData, data.count != 0 else {
                completionHandler(.failure(.invalidData))
                return
            }
            
            let decoder = JSONDecoder()
            do {
                let result = try decoder.decode(T.self, from: data)
                completionHandler(.success(result))
            } catch {
                completionHandler(.failure(.decodingError(error.localizedDescription)))
            }
        }.resume()
    }
}
